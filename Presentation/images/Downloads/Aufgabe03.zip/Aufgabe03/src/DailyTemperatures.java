import java.util.Scanner;
public class DailyTemperatures {
public static void main(String[]args){
	
	//Ausgabe//
System.out.println(" Temperaturanzeiger ");
int[] Tag = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };

}
}


