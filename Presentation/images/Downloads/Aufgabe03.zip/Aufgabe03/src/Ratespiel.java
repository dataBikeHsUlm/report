/*Lisa Brockhoff
 Martikel Nr: 3126402
 */
import java.util.Random;
import java.util.Scanner;
public class Ratespiel {
public static void main(String[]args){
	
	Random r = new Random();
	
	System.out.println(" Ich habe mir eine Zahl zwischen 1 und 100 ausgedacht, rate mal! ");

	int iZufallszahl = r.nextInt(100 + 1);
	
	Scanner scan = new Scanner(System.in);
	
	int iZahl= -1;
	while (iZufallszahl!=iZahl){
		System.out.println(" Geben Sie eine Zahl ein: ");
		iZahl=scan.nextInt();
		if(iZahl>iZufallszahl){
			System.out.println(" Die Zahl ist kleiner ");
		}
		else if(iZahl<iZufallszahl){
			System.out.println(" Die Zahl ist groesser ");
		}else{
			System.out.println(" Die Zahl ist richtig, Gl�ckwusch! " + iZahl + " = " + iZufallszahl);
			
		}
	}
}
}	
