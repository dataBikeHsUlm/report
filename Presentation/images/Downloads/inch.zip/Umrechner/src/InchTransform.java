import java.util.Scanner;
public class InchTransform {
public static void mai(String[]args){
	Scanner scan = new Scanner(System.in);
	
	System.out.println(" Bitte Inch eingeben: ");
	int inch = scan.nextInt();
	
	int in = 1;
	int ft = 12;
	int yd = 3 * ft;
	int mi = 1760 * yd;
	
	int meilen = inch / mi;
	System.out.println(" Meilen " + meilen);
	int rest = inch % mi;
	
	int yard = rest / yd;
	System.out.println(" Yards " + yard);
	rest = rest % yd;
	
	int feet = rest / ft;
	System.out.println(" Feet " + feet);
	rest = rest % ft;
	
	inch = rest;
	System.out.println(" Inch " + inch);
	
	
}
}
