import java.util.Scanner;
public class CalcLenght {
public static void main(String[]args){
	Scanner scan = new Scanner(System.in);
	
	System.out.println(" Bitte Meilen eingeben ");
	double meilen = scan.nextDouble();
	
	System.out.println(" Bitte Yards eingeben ");
	double yards = scan.nextDouble();
	
	System.out.println(" Bitte Feet eingeben ");
	double feet = scan.nextDouble();
	
	System.out.println(" Bitte Inch eingeben ");
	double inch = scan.nextDouble();
	
	double MeilenInMeter = meilen * 1.61 * 1000;
	double YardsInMeter = yards * 0.9144;
	double FeetInMeter = feet * 0.3048;
	double InchInMeter = inch * 0.0254;
	
	double gesamtlaengeInMeter = MeilenInMeter + YardsInMeter + FeetInMeter + InchInMeter;
	
	System.out.println(" Die Gesamtlaenge in Meter betraegt: " + gesamtlaengeInMeter);
	
}
}
