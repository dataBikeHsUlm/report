StackAPI is written and maintained by Andrew Wegner and
(hopefully soon) various contributors.

Project Owner
`````````````

Andrew Wegner `@AWegnerGitHub <https://github.com/AWegnerGitHub/stackapi>`_

Patches and Suggestions
```````````````````````

`@ArtOfCode- <https://github.com/ArtOfCode->`_


:ref:`Contribute <contributing>` a feature and get your name here!