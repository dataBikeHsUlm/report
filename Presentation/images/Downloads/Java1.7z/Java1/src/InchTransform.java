import java.util.Scanner;
public class InchTransform {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int eingabe,meilen,yards,feet,inch;
		
		System.out.print("Geben Sie Inch ein: ");
		eingabe = scan.nextInt();
		
		
		meilen = eingabe / (1760*3*12);
		yards = eingabe % (1760*3*12)/(3*12);
		feet = eingabe % (1760*3*12)%(3*12)/12;
		inch = eingabe % (1760*3*12)%(3*12)%12;
		
		System.out.print(eingabe+" Inch sind "+meilen+" Meilen,"+yards+" Yards, "+feet+" Fuss und "+inch+" Inch");
		
		scan.close();
	}

}
// Angelika Liesener Mat.Nr.:3128108