package java.util;

public class scanner {

	public static void close() {
		// TODO Auto-generated method stub
		
	}

}
