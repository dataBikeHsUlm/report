import java.util.Scanner;
public class CalcLength {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		double meilen,yards,feet,inch,gesamt;
		double m_von_inch,m_von_feet,m_von_yards,m_von_meilen;
	
		
		System.out.print("Geben Sie Meilen ein: ");
		meilen = scan.nextDouble();
		
		System.out.print("Geben Sie Yards ein: ");
		yards = scan.nextDouble();
		
		System.out.print("Geben Sie Feet ein: ");
		feet = scan.nextDouble();
		
		System.out.print("Geben Sie Inch ein: ");
		inch = scan.nextDouble();
		

		
		m_von_inch= inch *0.0254;
		m_von_feet= 12*feet*0.0254;
		m_von_yards=3*yards*12*0.0254;
		m_von_meilen=1760*meilen*12*3*0.0254;
		
		
		gesamt=m_von_inch+m_von_feet+m_von_yards+m_von_meilen;
		
		
		
		
		double ge= Math.round(gesamt*100)/100.0;
		
		System.out.print("Die Gesamtl�nge ist "+ge+" Meter.");
		

		scan.close();
				

	}

}

// Angelika Liesener Mat.Nr.: 3128108
